using System.Collections;
using UnityEngine;

public class MovePlayer : MonoBehaviour
{
    private float baseSpeed = 30f;
    private float currentSpeed;
    private CharacterController characterController;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
        currentSpeed = baseSpeed;
    }

    void Update()
    {
        // Check for "Shift" key to temporarily double the speed
        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            currentSpeed = baseSpeed * 2f; // Double the speed
        }
        else
        {
            currentSpeed = baseSpeed; // Reset to the base speed
        }

        // Move the character based on the input and current speed
        Vector3 characterMove = new Vector3(Input.GetAxis("Vertical") * Time.deltaTime * currentSpeed, 0, 0);
        characterController.Move(characterMove);
    }
}

