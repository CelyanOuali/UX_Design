using System.Collections;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [SerializeField]
    private GameObject gameObjectToInstantiate;
    private GameObject currentSphere;

    private IEnumerator WaitBetweenSpawns()
    {
        yield return new WaitForSeconds(2f);

        // Check if there's a current sphere, destroy it before instantiating a new one
        if (currentSphere != null)
        {
            Destroy(currentSphere);
        }

        // Get the x length of the GameObject
        float xLength = GetComponent<MeshRenderer>().bounds.size.x;

        // Randomize the position within the GameObject's x length for X and Z, while keeping Y fixed
        Vector3 randomPosition = new Vector3(Random.Range(4, 22), 18.61f, -8.73f);

        // Instantiate the GameObject at the random position
        currentSphere = Instantiate(gameObjectToInstantiate, randomPosition, Quaternion.identity);
    }

    public void StartWaitBetweenSpawns()
    {
        StartCoroutine(WaitBetweenSpawns());
    }

    public void InstantiateStart()
    {
        // Initial instantiation
        StartWaitBetweenSpawns();
    }

    public void NotifySphereDestroyed()
    {
        // Called when the sphere is destroyed, initiate respawn logic if needed
        StartWaitBetweenSpawns();
    }
}
