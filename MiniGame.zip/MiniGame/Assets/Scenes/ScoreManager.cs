using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    private int score = 0;
    public TextMeshProUGUI ScoreNumber; // Attach the TextMeshPro component to this variable in the Unity Editor

    private void Start()
    {
        UpdateScoreText();
    }

    public void IncreaseScore()
    {
        score++;
        UpdateScoreText();
    }

    public void DecreaseScore()
    {
        score--;
        UpdateScoreText();
    }

    private void UpdateScoreText()
    {
        // Update the TextMeshPro text to display the current score
        if (ScoreNumber != null)
        {
            ScoreNumber.text = "Score: " + score.ToString();
        }
    }
}
