using UnityEngine;
using System.Collections;

public class SphereCollisionHandler : MonoBehaviour
{
    private Spawner spawner; // Reference to the Spawner script
    private ScoreManager scoreManager; // Reference to the ScoreManager script
    private bool hasCollided = false; // Flag to check if the sphere has already collided

    private void Start()
    {
        // Find the Spawner script in the scene
        spawner = FindObjectOfType<Spawner>();

        // Find the ScoreManager script in the scene
        scoreManager = FindObjectOfType<ScoreManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        // Check if the collision is with the player or plane and if the sphere has not collided before
        if ((other.CompareTag("Player") || other.CompareTag("Plane")) && !hasCollided)
        {
            // Set the flag to true to avoid further collisions
            hasCollided = true;

            // Handle scoring logic
            if (scoreManager != null)
            {
                // Increase or decrease the score based on your criteria
                // For example, you can increase the score when colliding with the player and decrease when colliding with the plane
                if (other.CompareTag("Player"))
                {
                    scoreManager.IncreaseScore();
                }
                else if (other.CompareTag("Plane"))
                {
                    scoreManager.DecreaseScore();
                }
            }

            // Notify the spawner that the sphere needs to be respawned
            if (spawner != null)
            {
                spawner.NotifySphereDestroyed();
            }

            // Destroy the sphere when it touches the player or plane
            Destroy(gameObject);
        }
    }
}
